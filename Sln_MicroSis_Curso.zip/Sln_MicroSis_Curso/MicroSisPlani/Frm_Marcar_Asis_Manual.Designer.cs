﻿namespace MicroSisPlani
{
    partial class Frm_Marcar_Asis_Manual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle8 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle7 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle6 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle3 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle4 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle5 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle1 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            Klik.Windows.Forms.v1.Common.PaintStyle paintStyle2 = new Klik.Windows.Forms.v1.Common.PaintStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Marcar_Asis_Manual));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pnl_titulo = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_Salir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_hora = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.Lbl_HoraEntrada = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.pnl_Msm = new System.Windows.Forms.Panel();
            this.lbl_waiting = new System.Windows.Forms.Label();
            this.lbl_Cont = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lbl_msm = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Lbl_Idperso = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lbl_Dni = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.picSocio = new System.Windows.Forms.PictureBox();
            this.lbl_nombresocio = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_totaltarde = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.lbl_justifi = new Klik.Windows.Forms.v1.EntryLib.ELLabel();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.lbl_TotalHotrabajda = new System.Windows.Forms.Label();
            this.dtp_hora_tolercia = new System.Windows.Forms.DateTimePicker();
            this.Label24 = new System.Windows.Forms.Label();
            this.Label25 = new System.Windows.Forms.Label();
            this.Label26 = new System.Windows.Forms.Label();
            this.Dtp_Hora_Limite = new System.Windows.Forms.DateTimePicker();
            this.Label27 = new System.Windows.Forms.Label();
            this.dtp_horaIngre = new System.Windows.Forms.DateTimePicker();
            this.dtp_horaSalida = new System.Windows.Forms.DateTimePicker();
            this.lbl_IdAsis = new System.Windows.Forms.Label();
            this.dtp_HoraActual = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.txt_dni_Buscar = new Klik.Windows.Forms.v1.EntryLib.ELEntryBox();
            this.tmr_Conta = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pnl_titulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_hora)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lbl_HoraEntrada)).BeginInit();
            this.pnl_Msm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_Cont)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lbl_Idperso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_Dni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSocio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_nombresocio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_totaltarde)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_justifi)).BeginInit();
            this.GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_dni_Buscar)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 20;
            this.bunifuElipse1.TargetControl = this;
            // 
            // pnl_titulo
            // 
            this.pnl_titulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnl_titulo.Controls.Add(this.label7);
            this.pnl_titulo.Controls.Add(this.btn_Salir);
            this.pnl_titulo.Controls.Add(this.label1);
            this.pnl_titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_titulo.Location = new System.Drawing.Point(0, 0);
            this.pnl_titulo.Name = "pnl_titulo";
            this.pnl_titulo.Size = new System.Drawing.Size(1114, 50);
            this.pnl_titulo.TabIndex = 8;
           
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(35, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(225, 24);
            this.label7.TabIndex = 25;
            this.label7.Text = "Marcar Asistencia Manual";
            // 
            // btn_Salir
            // 
            this.btn_Salir.FlatAppearance.BorderSize = 0;
            this.btn_Salir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Salir.ForeColor = System.Drawing.Color.White;
            this.btn_Salir.Image = ((System.Drawing.Image)(resources.GetObject("btn_Salir.Image")));
            this.btn_Salir.Location = new System.Drawing.Point(3, 10);
            this.btn_Salir.Name = "btn_Salir";
            this.btn_Salir.Size = new System.Drawing.Size(30, 30);
            this.btn_Salir.TabIndex = 1;
            this.btn_Salir.UseVisualStyleBackColor = true;
          
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.Location = new System.Drawing.Point(0, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1114, 4);
            this.label1.TabIndex = 0;
            // 
            // lbl_hora
            // 
            this.lbl_hora.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_hora.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_hora.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle8.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle8.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_hora.FlashStyle = paintStyle8;
            this.lbl_hora.ForegroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
            this.lbl_hora.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_hora.Location = new System.Drawing.Point(953, 56);
            this.lbl_hora.Name = "lbl_hora";
            this.lbl_hora.Size = new System.Drawing.Size(149, 32);
            this.lbl_hora.TabIndex = 126;
            this.lbl_hora.TabStop = false;
            this.lbl_hora.TextStyle.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hora.TextStyle.Text = "00:00:00";
            this.lbl_hora.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_hora.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // Lbl_HoraEntrada
            // 
            this.Lbl_HoraEntrada.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.Lbl_HoraEntrada.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.Lbl_HoraEntrada.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle7.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle7.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.Lbl_HoraEntrada.FlashStyle = paintStyle7;
            this.Lbl_HoraEntrada.ForegroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.Lbl_HoraEntrada.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Lbl_HoraEntrada.Location = new System.Drawing.Point(3, 56);
            this.Lbl_HoraEntrada.Name = "Lbl_HoraEntrada";
            this.Lbl_HoraEntrada.Size = new System.Drawing.Size(106, 32);
            this.Lbl_HoraEntrada.TabIndex = 127;
            this.Lbl_HoraEntrada.TabStop = false;
            this.Lbl_HoraEntrada.TextStyle.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_HoraEntrada.TextStyle.ForeColor = System.Drawing.Color.DimGray;
            this.Lbl_HoraEntrada.TextStyle.Text = "00:00";
            this.Lbl_HoraEntrada.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Lbl_HoraEntrada.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // pnl_Msm
            // 
            this.pnl_Msm.Controls.Add(this.lbl_waiting);
            this.pnl_Msm.Controls.Add(this.lbl_Cont);
            this.pnl_Msm.Location = new System.Drawing.Point(442, 189);
            this.pnl_Msm.Name = "pnl_Msm";
            this.pnl_Msm.Size = new System.Drawing.Size(211, 45);
            this.pnl_Msm.TabIndex = 130;
            this.pnl_Msm.Visible = false;
            // 
            // lbl_waiting
            // 
            this.lbl_waiting.AutoSize = true;
            this.lbl_waiting.BackColor = System.Drawing.Color.Transparent;
            this.lbl_waiting.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_waiting.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_waiting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_waiting.Location = new System.Drawing.Point(33, 15);
            this.lbl_waiting.Name = "lbl_waiting";
            this.lbl_waiting.Size = new System.Drawing.Size(127, 17);
            this.lbl_waiting.TabIndex = 128;
            this.lbl_waiting.Text = "Espere por Favor ..";
            this.lbl_waiting.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Cont
            // 
            this.lbl_Cont.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_Cont.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_Cont.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle6.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle6.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_Cont.FlashStyle = paintStyle6;
            this.lbl_Cont.ForegroundImageStyle.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.lbl_Cont.ForegroundImageStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_Cont.Location = new System.Drawing.Point(6, 7);
            this.lbl_Cont.Name = "lbl_Cont";
            this.lbl_Cont.Size = new System.Drawing.Size(199, 32);
            this.lbl_Cont.TabIndex = 127;
            this.lbl_Cont.TabStop = false;
            this.lbl_Cont.TextStyle.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cont.TextStyle.ForeColor = System.Drawing.Color.DimGray;
            this.lbl_Cont.TextStyle.Text = "10";
            this.lbl_Cont.TextStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_Cont.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lbl_msm
            // 
            this.lbl_msm.BackColor = System.Drawing.Color.Transparent;
            this.lbl_msm.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_msm.ForeColor = System.Drawing.Color.White;
            this.lbl_msm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_msm.Location = new System.Drawing.Point(12, 112);
            this.lbl_msm.Name = "lbl_msm";
            this.lbl_msm.Size = new System.Drawing.Size(1090, 70);
            this.lbl_msm.TabIndex = 131;
            this.lbl_msm.Text = "Dni:";
            this.lbl_msm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(724, 298);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 20);
            this.label5.TabIndex = 138;
            this.label5.Text = "Dni";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Location = new System.Drawing.Point(216, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 137;
            this.label2.Text = "ID Personal:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Lbl_Idperso
            // 
            this.Lbl_Idperso.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.Lbl_Idperso.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.Lbl_Idperso.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle3.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle3.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.Lbl_Idperso.FlashStyle = paintStyle3;
            this.Lbl_Idperso.Location = new System.Drawing.Point(218, 321);
            this.Lbl_Idperso.Name = "Lbl_Idperso";
            this.Lbl_Idperso.Size = new System.Drawing.Size(91, 23);
            this.Lbl_Idperso.TabIndex = 136;
            this.Lbl_Idperso.TabStop = false;
            this.Lbl_Idperso.TextStyle.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Idperso.TextStyle.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Lbl_Idperso.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lbl_Dni
            // 
            this.lbl_Dni.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_Dni.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_Dni.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle4.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle4.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_Dni.FlashStyle = paintStyle4;
            this.lbl_Dni.Location = new System.Drawing.Point(728, 321);
            this.lbl_Dni.Name = "lbl_Dni";
            this.lbl_Dni.Size = new System.Drawing.Size(91, 23);
            this.lbl_Dni.TabIndex = 135;
            this.lbl_Dni.TabStop = false;
            this.lbl_Dni.TextStyle.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dni.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // picSocio
            // 
            this.picSocio.Image = ((System.Drawing.Image)(resources.GetObject("picSocio.Image")));
            this.picSocio.Location = new System.Drawing.Point(478, 295);
            this.picSocio.Name = "picSocio";
            this.picSocio.Size = new System.Drawing.Size(176, 166);
            this.picSocio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSocio.TabIndex = 134;
            this.picSocio.TabStop = false;
            // 
            // lbl_nombresocio
            // 
            this.lbl_nombresocio.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_nombresocio.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_nombresocio.BorderStyle.SolidColor = System.Drawing.Color.WhiteSmoke;
            paintStyle5.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle5.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_nombresocio.FlashStyle = paintStyle5;
            this.lbl_nombresocio.Location = new System.Drawing.Point(218, 251);
            this.lbl_nombresocio.Name = "lbl_nombresocio";
            this.lbl_nombresocio.Size = new System.Drawing.Size(766, 32);
            this.lbl_nombresocio.TabIndex = 133;
            this.lbl_nombresocio.TabStop = false;
            this.lbl_nombresocio.TextStyle.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombresocio.TextStyle.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbl_nombresocio.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(219, 228);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 20);
            this.label6.TabIndex = 132;
            this.label6.Text = "Nombre Socio:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_totaltarde
            // 
            this.lbl_totaltarde.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_totaltarde.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_totaltarde.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle1.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle1.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_totaltarde.FlashStyle = paintStyle1;
            this.lbl_totaltarde.Location = new System.Drawing.Point(937, 321);
            this.lbl_totaltarde.Name = "lbl_totaltarde";
            this.lbl_totaltarde.Size = new System.Drawing.Size(52, 23);
            this.lbl_totaltarde.TabIndex = 140;
            this.lbl_totaltarde.TextStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totaltarde.TextStyle.Text = "0";
            this.lbl_totaltarde.Visible = false;
            this.lbl_totaltarde.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // lbl_justifi
            // 
            this.lbl_justifi.BackgroundStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.lbl_justifi.BackgroundStyle.SolidColor = System.Drawing.Color.White;
            this.lbl_justifi.BorderStyle.SolidColor = System.Drawing.Color.Gainsboro;
            paintStyle2.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            paintStyle2.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.lbl_justifi.FlashStyle = paintStyle2;
            this.lbl_justifi.Location = new System.Drawing.Point(840, 321);
            this.lbl_justifi.Name = "lbl_justifi";
            this.lbl_justifi.Size = new System.Drawing.Size(91, 23);
            this.lbl_justifi.TabIndex = 139;
            this.lbl_justifi.TabStop = false;
            this.lbl_justifi.TextStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_justifi.Visible = false;
            this.lbl_justifi.VisualStyle = Klik.Windows.Forms.v1.Common.ControlVisualStyles.Custom;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.Label21);
            this.GroupBox2.Controls.Add(this.lbl_TotalHotrabajda);
            this.GroupBox2.Controls.Add(this.dtp_hora_tolercia);
            this.GroupBox2.Controls.Add(this.Label24);
            this.GroupBox2.Controls.Add(this.Label25);
            this.GroupBox2.Controls.Add(this.Label26);
            this.GroupBox2.Controls.Add(this.Dtp_Hora_Limite);
            this.GroupBox2.Controls.Add(this.Label27);
            this.GroupBox2.Controls.Add(this.dtp_horaIngre);
            this.GroupBox2.Controls.Add(this.dtp_horaSalida);
            this.GroupBox2.Location = new System.Drawing.Point(15, 347);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(193, 155);
            this.GroupBox2.TabIndex = 141;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "HORARIOS DEFINIDOS";
            this.GroupBox2.Visible = false;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Location = new System.Drawing.Point(36, 137);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(37, 13);
            this.Label21.TabIndex = 18;
            this.Label21.Text = "idAsis:";
            // 
            // lbl_TotalHotrabajda
            // 
            this.lbl_TotalHotrabajda.AutoSize = true;
            this.lbl_TotalHotrabajda.Location = new System.Drawing.Point(79, 137);
            this.lbl_TotalHotrabajda.Name = "lbl_TotalHotrabajda";
            this.lbl_TotalHotrabajda.Size = new System.Drawing.Size(13, 13);
            this.lbl_TotalHotrabajda.TabIndex = 17;
            this.lbl_TotalHotrabajda.Text = "0";
            // 
            // dtp_hora_tolercia
            // 
            this.dtp_hora_tolercia.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_hora_tolercia.Location = new System.Drawing.Point(79, 47);
            this.dtp_hora_tolercia.Name = "dtp_hora_tolercia";
            this.dtp_hora_tolercia.Size = new System.Drawing.Size(104, 20);
            this.dtp_hora_tolercia.TabIndex = 13;
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Location = new System.Drawing.Point(18, 79);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(54, 13);
            this.Label24.TabIndex = 12;
            this.Label24.Text = "hora limite";
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Location = new System.Drawing.Point(26, 47);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(47, 13);
            this.Label25.TabIndex = 9;
            this.Label25.Text = "tolrancia";
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Location = new System.Drawing.Point(15, 111);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(58, 13);
            this.Label26.TabIndex = 8;
            this.Label26.Text = "hora salida";
            // 
            // Dtp_Hora_Limite
            // 
            this.Dtp_Hora_Limite.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.Dtp_Hora_Limite.Location = new System.Drawing.Point(79, 73);
            this.Dtp_Hora_Limite.Name = "Dtp_Hora_Limite";
            this.Dtp_Hora_Limite.Size = new System.Drawing.Size(104, 20);
            this.Dtp_Hora_Limite.TabIndex = 11;
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Location = new System.Drawing.Point(8, 19);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(65, 13);
            this.Label27.TabIndex = 7;
            this.Label27.Text = "hora ingreso";
            // 
            // dtp_horaIngre
            // 
            this.dtp_horaIngre.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_horaIngre.Location = new System.Drawing.Point(79, 19);
            this.dtp_horaIngre.Name = "dtp_horaIngre";
            this.dtp_horaIngre.Size = new System.Drawing.Size(104, 20);
            this.dtp_horaIngre.TabIndex = 5;
            // 
            // dtp_horaSalida
            // 
            this.dtp_horaSalida.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_horaSalida.Location = new System.Drawing.Point(79, 105);
            this.dtp_horaSalida.Name = "dtp_horaSalida";
            this.dtp_horaSalida.Size = new System.Drawing.Size(104, 20);
            this.dtp_horaSalida.TabIndex = 6;
            // 
            // lbl_IdAsis
            // 
            this.lbl_IdAsis.AutoSize = true;
            this.lbl_IdAsis.Location = new System.Drawing.Point(725, 357);
            this.lbl_IdAsis.Name = "lbl_IdAsis";
            this.lbl_IdAsis.Size = new System.Drawing.Size(10, 13);
            this.lbl_IdAsis.TabIndex = 19;
            this.lbl_IdAsis.Text = "-";
            // 
            // dtp_HoraActual
            // 
            this.dtp_HoraActual.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_HoraActual.Location = new System.Drawing.Point(980, 94);
            this.dtp_HoraActual.Name = "dtp_HoraActual";
            this.dtp_HoraActual.Size = new System.Drawing.Size(104, 20);
            this.dtp_HoraActual.TabIndex = 142;
            this.dtp_HoraActual.Visible = false;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Location = new System.Drawing.Point(364, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 34);
            this.label3.TabIndex = 144;
            this.label3.Text = "Dni:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_buscar
            // 
            this.btn_buscar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_buscar.FlatAppearance.BorderSize = 0;
            this.btn_buscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_buscar.ForeColor = System.Drawing.Color.White;
            this.btn_buscar.Image = ((System.Drawing.Image)(resources.GetObject("btn_buscar.Image")));
            this.btn_buscar.Location = new System.Drawing.Point(633, 64);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(32, 32);
            this.btn_buscar.TabIndex = 145;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Visible = false;
            
            // 
            // txt_dni_Buscar
            // 
            this.txt_dni_Buscar.CaptionStyle.CaptionSize = 0;
            this.txt_dni_Buscar.CaptionStyle.FlashStyle.PaintType = Klik.Windows.Forms.v1.Common.PaintTypes.Solid;
            this.txt_dni_Buscar.CaptionStyle.FlashStyle.SolidColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(191)))));
            this.txt_dni_Buscar.CaptionStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernBlack;
            this.txt_dni_Buscar.CaptionStyle.TextStyle.ForeColor = System.Drawing.Color.White;
            this.txt_dni_Buscar.CaptionStyle.TextStyle.Text = "elEntryBox1";
            this.txt_dni_Buscar.EditBoxStyle.BorderStyle.BorderType = Klik.Windows.Forms.v1.Common.BorderTypes.None;
            this.txt_dni_Buscar.EditBoxStyle.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dni_Buscar.EditBoxStyle.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_dni_Buscar.EditBoxStyle.Office2007Scheme = Klik.Windows.Forms.v1.Common.Office2007Schemes.ModernBlack;
            this.txt_dni_Buscar.EditBoxStyle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_dni_Buscar.Location = new System.Drawing.Point(357, 56);
            this.txt_dni_Buscar.Name = "txt_dni_Buscar";
            this.txt_dni_Buscar.Size = new System.Drawing.Size(273, 48);
            this.txt_dni_Buscar.TabIndex = 1;
            this.txt_dni_Buscar.ValidationStyle.MaxLength = 8;
            this.txt_dni_Buscar.ValidationStyle.PasswordChar = '\0';
            this.txt_dni_Buscar.ValidationStyle.UseSystemPasswordChar = true;
            this.txt_dni_Buscar.Value = "";
            
            // 
            // tmr_Conta
            // 
            this.tmr_Conta.Interval = 1000;
           
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
           
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            // 
            // Frm_Marcar_Asis_Manual
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1114, 514);
            this.Controls.Add(this.lbl_IdAsis);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.txt_dni_Buscar);
            this.Controls.Add(this.dtp_HoraActual);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.lbl_totaltarde);
            this.Controls.Add(this.lbl_justifi);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Lbl_Idperso);
            this.Controls.Add(this.lbl_Dni);
            this.Controls.Add(this.picSocio);
            this.Controls.Add(this.lbl_nombresocio);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_msm);
            this.Controls.Add(this.pnl_Msm);
            this.Controls.Add(this.Lbl_HoraEntrada);
            this.Controls.Add(this.lbl_hora);
            this.Controls.Add(this.pnl_titulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Marcar_Asis_Manual";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Marcar Asistencia";
            this.Load += new System.EventHandler(this.Frm_Marcar_Asis_Manual_Load);
            this.pnl_titulo.ResumeLayout(false);
            this.pnl_titulo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_hora)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lbl_HoraEntrada)).EndInit();
            this.pnl_Msm.ResumeLayout(false);
            this.pnl_Msm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_Cont)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lbl_Idperso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_Dni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSocio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_nombresocio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_totaltarde)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lbl_justifi)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_dni_Buscar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel pnl_titulo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_Salir;
        private System.Windows.Forms.Label label1;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_hora;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel Lbl_HoraEntrada;
        private System.Windows.Forms.Panel pnl_Msm;
        private System.Windows.Forms.Label lbl_waiting;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_Cont;
        private System.Windows.Forms.Label lbl_msm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel Lbl_Idperso;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_Dni;
        private System.Windows.Forms.PictureBox picSocio;
        private Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_nombresocio;
        private System.Windows.Forms.Label label6;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_totaltarde;
        public Klik.Windows.Forms.v1.EntryLib.ELLabel lbl_justifi;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label lbl_IdAsis;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label lbl_TotalHotrabajda;
        internal System.Windows.Forms.DateTimePicker dtp_hora_tolercia;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.DateTimePicker Dtp_Hora_Limite;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.DateTimePicker dtp_horaIngre;
        internal System.Windows.Forms.DateTimePicker dtp_horaSalida;
        internal System.Windows.Forms.DateTimePicker dtp_HoraActual;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_buscar;
        private Klik.Windows.Forms.v1.EntryLib.ELEntryBox txt_dni_Buscar;
        private System.Windows.Forms.Timer tmr_Conta;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}