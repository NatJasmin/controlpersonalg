﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace Prj_Capa_Datos
{
  class BD_Personal 
    {

      



    }
}
